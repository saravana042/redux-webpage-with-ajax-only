import React, { Component } from 'react';

export default class Chart extends Component {
  render() {
    return (
      <div>  Chart </div>
    );
  }
}
