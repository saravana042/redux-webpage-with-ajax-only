import React, { Component } from 'react';

export default class Footer extends Component {
  render() {
    return (
		<div className="container-fluid fixed-bottom navbar-fixed-bottom">

			<nav className="navbar navbar-toggleable-md navbar-light bg-faded">
				<a className="navbar-brand logo-name ml-auto" href="#">
					Cisco
				</a>
			</nav>

		</div>
    );
  }
}
