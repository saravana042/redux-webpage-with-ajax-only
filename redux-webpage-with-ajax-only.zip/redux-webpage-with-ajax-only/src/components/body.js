import React, { Component } from 'react';

export default class Body extends Component {
  render() {
    return (
      <div>  React simple starter </div>
    );
  }
}
